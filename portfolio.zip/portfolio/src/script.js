<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Background Effect</title>
  <style>
    body {
      margin: 0;
      height: 100vh;
      overflow: hidden;
    }

    /* Canvas for animated lines */
    canvas {
      position: fixed;
      top: 0;
      left: 0;
      z-index: -1;
    }
  </style>
</head>
<body>
  <h1 style="color:white; text-align:center; padding-top:40vh;">
    Black & Blue Mixed Line Background
  </h1>

  <script>
    const canvas = document.createElement("canvas");
    document.body.appendChild(canvas);
    const ctx = canvas.getContext("2d");

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    // Resize canvas dynamically
    window.addEventListener("resize", () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    });

    class Line {
      constructor() {
        this.x = Math.random() * canvas.width;
        this.y = Math.random() * canvas.height;
        this.length = Math.random() * 200 + 100;
        this.speed = Math.random() * 2 + 1;
        this.angle = Math.random() * Math.PI * 2;
        this.color = Math.random() > 0.5 ? "rgba(0,0,255,0.7)" : "rgba(0,0,0,0.7)";
      }
      update() {
        this.x += Math.cos(this.angle) * this.speed;
        this.y += Math.sin(this.angle) * this.speed;

        if (this.x < 0 || this.x > canvas.width || this.y < 0 || this.y > canvas.height) {
          this.x = Math.random() * canvas.width;
          this.y = Math.random() * canvas.height;
        }
      }
      draw() {
        ctx.strokeStyle = this.color;
        ctx.beginPath();
        ctx.moveTo(this.x, this.y);
        ctx.lineTo(this.x + Math.cos(this.angle) * this.length,
                   this.y + Math.sin(this.angle) * this.length);
        ctx.stroke();
      }
    }

    const lines = [];
    for (let i = 0; i < 50; i++) {
      lines.push(new Line());
    }

    function animate() {
      ctx.fillStyle = "rgba(0,0,0,0.2)"; // fade effect background
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      lines.forEach(line => {
        line.update();
        line.draw();
      });
      requestAnimationFrame(animate);
    }

    animate();
  </script>
</body>
</html>